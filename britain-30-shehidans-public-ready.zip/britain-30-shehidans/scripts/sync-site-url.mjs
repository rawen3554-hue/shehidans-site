import { readFile, writeFile } from 'node:fs/promises';
const config = JSON.parse(await readFile('.firebaserc', 'utf8'));
const projectId = config?.projects?.default;
if (!projectId || projectId === 'YOUR-FIREBASE-PROJECT-ID') {
  console.error('No Firebase project selected. Run: npx firebase use --add');
  process.exit(1);
}
const publicUrl = `https://${projectId}.web.app/`;
for (const path of ['public/index.html','public/robots.txt','public/sitemap.xml','public/firebase-config.js']) {
  const old = await readFile(path, 'utf8');
  const next = old.replaceAll('YOUR-FIREBASE-PROJECT-ID', projectId);
  if (next !== old) await writeFile(path, next, 'utf8');
}
console.log(`Prepared canonical URL and crawler files for ${publicUrl}`);
