// Firebase web config is public by design. Do not put private service-account keys here.
// Fill these values from Firebase Console > Project settings > Your apps > Web app.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR-FIREBASE-PROJECT-ID.firebaseapp.com",
  projectId: "YOUR-FIREBASE-PROJECT-ID",
  appId: "YOUR_FIREBASE_WEB_APP_ID"
};

// The owner's Firebase Authentication UID. Firestore rules independently enforce it.
// Find it in Firebase Console > Authentication > Users after the owner signs in once.
export const ownerUid = "OWNER_UID_GOES_HERE";

export const siteConfig = {
  title: "Britain, 30 Shehidans",
  publicUrl: "https://YOUR-FIREBASE-PROJECT-ID.web.app/"
};
