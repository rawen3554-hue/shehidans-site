import { initializeApp } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged,
  reauthenticateWithPopup
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, deleteDoc, doc, onSnapshot,
  query, orderBy, serverTimestamp, updateDoc
} from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";
import { firebaseConfig, ownerUid } from "/firebase-config.js";

const $ = (id) => document.getElementById(id);
const configReady = Object.values(firebaseConfig).every(v => typeof v === "string" && v && !v.startsWith("YOUR"));
let app = null, auth = null, db = null, currentUser = null, gmailToken = null;
let isOwnerUnlocked = false, ownerMode = false, crownClicks = 0, toastTimer = null, currentAreaKey = "first";
const memory = { news: [], directory: [], areas: [] };
const unsubs = [];
const areaInfo = {
  first: {name:"First Alley", kurdish:"کۆڵانی یەکەم", description:"More information about this alley will appear here when it is published.", n:"01"},
  second: {name:"Second Alley — Mr Bean Fara", kurdish:"مستەر بین فارا", description:"More information about Mr Bean Fara will appear here when it is published.", n:"02"},
  third: {name:"Third Alley", kurdish:"کۆڵانی سێیەم", description:"More information about this alley will appear here when it is published.", n:"03"}
};
const avatarColors = ["#557eaa","#b36b67","#6c967b","#9877a8","#c08b54","#527f86","#7e8eae","#b16b94","#8a8a65","#5471a0"];
const googleProvider = new GoogleAuthProvider();

function notify(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}
function showStatus(message, warning=false) {
  $("statusText").textContent = message;
  $("statusStrip").classList.toggle("warning", warning);
  $("statusStrip").hidden = false;
}
function safeText(value) { return String(value ?? ""); }
function formatDate(value) {
  if (!value) return "Just added";
  const date = typeof value.toDate === "function" ? value.toDate() : new Date(value);
  return Number.isNaN(date.getTime()) ? "Just added" : date.toLocaleDateString(undefined,{year:"numeric",month:"short",day:"numeric"});
}
function openDialog(id) { const d=$(id); if (d && !d.open) d.showModal(); }
function closeDialog(id) { const d=$(id); if (d?.open) d.close(); }
function setPage(name) {
  $("ownerOrb").hidden = !isOwnerUnlocked || name !== "home";
  document.querySelectorAll(".nav-tab").forEach(t => t.classList.toggle("active", t.dataset.page === name));
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("is-visible", p.id === `page-${name}`));
  window.scrollTo({top:0,behavior:"smooth"});
}
function makeCard(item, type) {
  const article=document.createElement("article"); article.className="panel entry-card";
  const category=document.createElement("span"); category.className="entry-category";
  category.textContent=type === "news" ? "COMMUNITY UPDATE" : safeText(item.category || "DIRECTORY ENTRY");
  const h=document.createElement("h3"); h.textContent=safeText(item.title || item.name);
  const p=document.createElement("p"); p.textContent=safeText(item.body || item.description);
  const meta=document.createElement("div"); meta.className="feed-meta"; meta.textContent=formatDate(item.createdAt);
  article.append(category,h,p,meta);
  if (ownerMode && db) {
    const controls=document.createElement("div"); controls.className="entry-controls";
    const edit=document.createElement("button"); edit.className="text-link"; edit.type="button"; edit.textContent="Edit";
    edit.addEventListener("click",()=>editEntry(item,type));
    const del=document.createElement("button"); del.className="text-link"; del.type="button"; del.textContent="Delete";
    del.addEventListener("click",async()=>{
      if (!confirm("Delete this entry?")) return;
      try { await deleteDoc(doc(db,type === "news" ? "community" : type,item.id)); notify("Entry deleted."); }
      catch(e){ console.error(e); notify("Delete failed. Check the owner UID and database rules."); }
    });
    controls.append(edit,del); article.append(controls);
  }
  return article;
}
function renderNews() {
  const list=$("newsList"), home=$("homeNews"); list.replaceChildren(); home.replaceChildren();
  if (!memory.news.length) {
    list.innerHTML='<div class="empty-state wide"><span>▤</span><b>No community news yet</b><small>When an update is published, it will show up here for everyone.</small></div>';
    home.innerHTML='<div class="empty-state"><span>▤</span><b>No news published yet</b><small>Community updates will appear here.</small></div>';
    return;
  }
  [...memory.news].slice(0,3).forEach(item=>{home.append(makeCard(item,"news"));});
  memory.news.forEach(item=>list.append(makeCard(item,"news")));
}
function renderDirectory() {
  const list=$("directoryList"); list.replaceChildren();
  if(!memory.directory.length){list.innerHTML='<div class="empty-state wide"><span>▦</span><b>The directory is ready</b><small>Entries added by the site owner will appear here.</small></div>';return;}
  memory.directory.forEach(item=>list.append(makeCard(item,"directory")));
}
function setupFirebase() {
  if (!configReady) {
    showStatus("Preview mode: connect a Firebase project to enable shared data and public deployment.",true);
    renderNews(); renderDirectory(); return;
  }
  try {
    app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app);
    const newsQ=query(collection(db,"community"),orderBy("createdAt","desc"));
    const dirQ=query(collection(db,"directory"),orderBy("createdAt","desc"));
    const areaQ=query(collection(db,"areas"),orderBy("createdAt","desc"));
    unsubs.push(onSnapshot(newsQ,s=>{memory.news=s.docs.map(d=>({id:d.id,...d.data()}));renderNews();},e=>{console.error(e);showStatus("Community news could not load. Check Firestore setup.",true);}));
    unsubs.push(onSnapshot(dirQ,s=>{memory.directory=s.docs.map(d=>({id:d.id,...d.data()}));renderDirectory();},e=>{console.error(e);showStatus("Directory could not load. Check Firestore setup.",true);}));
    unsubs.push(onSnapshot(areaQ,s=>{memory.areas=s.docs.map(d=>({id:d.id,...d.data()}));updateAreaDetail(currentAreaKey);},e=>{console.error(e);showStatus("Area descriptions could not load. Check Firestore setup.",true);}));
    onAuthStateChanged(auth,user=>{currentUser=user; updateProfile(); updateOwnerPanel();});
    showStatus("Public browsing is open. Shared updates load from Google Firestore.");
  } catch(e) { console.error(e); showStatus("Firebase could not start. Check the web config.",true); }
}
function randomAvatar(user) {
  const key=`britain30_avatar_${user.uid}`;
  let value=sessionStorage.getItem(key);
  if(!value){
    const rare=Math.random()<0.01;
    value=rare?"fishy":avatarColors[Math.floor(Math.random()*avatarColors.length)];
    sessionStorage.setItem(key,value);
  }
  const button=$("profileButton"), letter=$("avatarLetter"), large=$("largeAvatar");
  button.classList.toggle("fishy",value==="fishy");
  button.style.background=value==="fishy"?"":`linear-gradient(135deg,${value},#294c70)`;
  large.style.background=value==="fishy"?"linear-gradient(#8fe4ea,#1478aa)":`linear-gradient(135deg,${value},#294c70)`;
  letter.textContent=(user.displayName||user.email||"?").trim().charAt(0).toUpperCase();
  large.textContent=letter.textContent;
}
function updateProfile() {
  const signed=!!currentUser;
  $("profileSignedOut").hidden=signed;
  $("profileSignedIn").hidden=!signed;
  if(signed){
    randomAvatar(currentUser);
    $("profileName").textContent=currentUser.displayName||"Google account";
    $("profileEmail").textContent=currentUser.email||"";
    $("profileUid").textContent=`Account ID: ${currentUser.uid}`;
  } else {
    $("avatarLetter").textContent="?";
    $("profileUid").textContent="";
    $("profileButton").classList.remove("fishy");
    $("profileButton").style.background="linear-gradient(135deg,#8bb1d3,#416c9a)";
  }
}
function isOwnerAccount() { return !!currentUser && !!ownerUid && ownerUid !== "OWNER_UID_GOES_HERE" && currentUser.uid === ownerUid; }
function updateOwnerPanel() {
  ownerMode=isOwnerUnlocked && isOwnerAccount();
  $("ownerSignInPrompt").hidden=ownerMode;
  $("ownerEditor").hidden=!ownerMode;
  $("editSelectedArea").hidden=!ownerMode;
  if(ownerMode) $("ownerMessage").textContent="Owner verified. Database security rules still enforce every write.";
  else if(!ownerUid || ownerUid==="OWNER_UID_GOES_HERE") $("ownerMessage").textContent=currentUser ? `Owner setup incomplete. Copy your Firebase UID (${currentUser.uid}) into ownerUid in firebase-config.js and firestore.rules.` : "Sign in using the profile button with the owner Google account, then set its Firebase UID in the project config and rules.";
  else if(isOwnerUnlocked && currentUser) $("ownerMessage").textContent="This Google account is not the configured owner account.";
  else if(isOwnerUnlocked) $("ownerMessage").textContent="Sign into your normal profile using the owner Google account.";
  renderNews();
  renderDirectory();
}
async function googleSignIn() {
  if(!auth){notify("Firebase sign-in is not configured yet.");return;}
  try {
    await signInWithPopup(auth,googleProvider);
    closeDialog("profileDialog");
    notify("Signed in with Google.");
  } catch(e){console.error(e);notify(e.code==="auth/popup-closed-by-user"?"Sign-in was cancelled.":"Google sign-in failed. Check Firebase Authentication settings.");}
}
async function signOutGoogle(){if(!auth)return;try{gmailToken=null;await signOut(auth);closeDialog("profileDialog");notify("Signed out.");}catch(e){console.error(e);notify("Could not sign out.");}}
async function connectGmail(){
  if(!auth||!currentUser){notify("Sign in with Google first.");return;}
  try{
    const provider=new GoogleAuthProvider();
    provider.addScope("https://www.googleapis.com/auth/gmail.readonly");
    provider.addScope("https://www.googleapis.com/auth/gmail.send");
    const result=await reauthenticateWithPopup(currentUser,provider);
    const credential=GoogleAuthProvider.credentialFromResult(result);
    if(!credential?.accessToken) throw new Error("No Gmail access token was returned.");
    gmailToken=credential.accessToken;
    $("gmailMessage").textContent="Gmail connected for this visit. The access token is kept in memory only.";
    notify("Gmail connected with read and send permissions only.");
  }catch(e){console.error(e);notify("Gmail connection failed. Check Gmail API and OAuth verification settings.");}
}
async function gmailFetch(path,options={}){
  if(!gmailToken)throw new Error("Connect Gmail first.");
  const response=await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/${path}`,{...options,headers:{Authorization:`Bearer ${gmailToken}`,...(options.headers||{})}});
  if(!response.ok){const msg=await response.text();throw new Error(`Gmail API ${response.status}: ${msg.slice(0,250)}`);}
  return response.json();
}
async function loadInbox(){
  $("gmailComposeForm").hidden=true; $("gmailInbox").replaceChildren();
  if(!gmailToken){$("gmailInbox").textContent="Connect Gmail from your profile first.";openDialog("gmailDialog");return;}
  $("gmailInbox").textContent="Loading inbox…"; $("gmailTitle").textContent="Gmail inbox"; openDialog("gmailDialog");
  try{
    const data=await gmailFetch("messages?maxResults=8&q=in%3Ainbox");
    $("gmailInbox").replaceChildren();
    for(const message of (data.messages||[])){
      const full=await gmailFetch(`messages/${encodeURIComponent(message.id)}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`);
      const headers=full.payload?.headers||[]; const get=n=>headers.find(h=>h.name.toLowerCase()===n.toLowerCase())?.value||"";
      const card=document.createElement("article");card.className="gmail-message";
      const subject=document.createElement("b");subject.textContent=get("Subject")||"(No subject)";
      const from=document.createElement("small");from.textContent=`${get("From")} · ${get("Date")}`;
      const snippet=document.createElement("p");snippet.textContent=full.snippet||"";
      card.append(subject,from,snippet); $("gmailInbox").append(card);
    }
    if(!data.messages?.length)$("gmailInbox").textContent="Your inbox has no messages to show.";
  }catch(e){console.error(e);$("gmailInbox").textContent=e.message;}
}
function base64Url(text){return btoa(unescape(encodeURIComponent(text))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,"");}
async function sendGmail(event){
  event.preventDefault(); if(!gmailToken){notify("Connect Gmail first.");return;}
  const to=$("mailTo").value.trim(), subject=$("mailSubject").value.trim(), body=$("mailBody").value;
  const raw=`To: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${body}`;
  try{await gmailFetch("messages/send",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({raw:base64Url(raw)})});$("gmailComposeForm").reset();notify("Email sent.");$("gmailMessage").textContent="Email sent successfully.";}
  catch(e){console.error(e);notify("Email could not be sent. Check the Gmail API permissions.");$("gmailMessage").textContent=e.message;}
}
function activateEditorTab(type){
  $("entryType").value=type;
  document.querySelectorAll(".mini-tab").forEach(t=>t.classList.toggle("active",t.dataset.editor===type));
  $("entryExtraLabel").textContent=type==="areas"?"Area key (first, second or third)":"Category (optional)";
  $("entryExtra").placeholder=type==="directory"?"Person, place, service…":type==="areas"?"first / second / third":"Category";
  $("entryTitle").placeholder=type==="directory"?"Name of the person or place":type==="areas"?"Area name":"Write a title";
  $("entryBody").placeholder=type==="directory"?"Public description (no private addresses or phone numbers)":"Write the details to publish";
}
function editEntry(item,type){
  if(!ownerMode){notify("Owner access is not verified.");return;}
  activateEditorTab(type);
  $("entryId").value=item.id||"";
  $("entryTitle").value=item.title||item.name||"";
  $("entryBody").value=item.body||item.description||"";
  $("entryExtra").value=type==="areas"?(item.areaKey||""):(item.category||"");
  openDialog("ownerDialog");
}
async function publishEntry(event){
  event.preventDefault();
  if(!db||!ownerMode||!isOwnerAccount()){notify("Owner access is not verified.");return;}
  const type=$("entryType").value;
  const title=$("entryTitle").value.trim(), body=$("entryBody").value.trim(), extra=$("entryExtra").value.trim();
  const editId=$("entryId").value;
  if(!title||!body)return;
  if(type==="areas" && !["first","second","third"].includes(extra)){notify("For an area, enter first, second or third as its key.");return;}
  const payload={title,body,category:type==="areas"?"Area":extra,areaKey:type==="areas"?extra:null,updatedAt:serverTimestamp(),createdBy:currentUser.uid};
  try{
    if(editId) await updateDoc(doc(db,type==="news"?"community":type,editId),payload);
    else await addDoc(collection(db,type==="news"?"community":type),{...payload,createdAt:serverTimestamp()});
    $("ownerEntryForm").reset();$("entryId").value="";notify(editId?"Changes saved for everyone.":"Published for everyone.");
  }
  catch(e){console.error(e);notify("Publish failed. Firestore blocked the write; check the owner UID in its rules.");}
}
function updateAreaDetail(key){
  const a=areaInfo[key]||areaInfo.first;
  const saved=memory.areas.find(item=>item.areaKey===key);
  $("areaName").textContent=saved?.title||a.name;
  $("areaKurdish").textContent=a.kurdish;
  $("areaDescription").textContent=saved?.body||a.description;
  $("areaCounter").textContent=`AREA ${a.n} / 03`;
  $("editSelectedArea").hidden=!ownerMode;
}
function selectArea(key){
  currentAreaKey=key in areaInfo?key:"first";
  updateAreaDetail(currentAreaKey);
  document.querySelectorAll(".area-choice").forEach(b=>b.classList.toggle("selected",b.dataset.area===currentAreaKey));
  setPage("areas");
}
function missionEffect(kind){
  const map={clock:{emoji:"🕰️",text:"An ancient clock appears…"},wizard:{emoji:"🧙",text:"A mysterious wizard has arrived…"},fire:{emoji:"🔥",text:"A flame lights the hidden path…"}};
  const value=map[kind];if(value){notify(`${value.emoji} ${value.text}`);$("crownTrigger").classList.add("mission-glow");setTimeout(()=>$ ("crownTrigger").classList.remove("mission-glow"),900);}
}
function handleCrown(){
  if(crownClicks>=4)return;
  crownClicks++;
  if(crownClicks===2)missionEffect("clock");
  if(crownClicks===3)missionEffect("wizard");
  if(crownClicks===4){missionEffect("fire");$("ownerClaimArea").hidden=false;}
}
function claimOwnership(){isOwnerUnlocked=true;$("ownerOrb").hidden=false;setPage("home");notify("The black orb has appeared on Home.");}
function openOwner(){if(!isOwnerUnlocked){notify("The hidden mission is not complete.");return;}openDialog("ownerDialog");updateOwnerPanel();}

// Navigation and page controls.
document.querySelectorAll(".nav-tab").forEach(b=>b.addEventListener("click",()=>setPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>setPage(b.dataset.go)));
document.querySelectorAll("[data-area]").forEach(b=>b.addEventListener("click",()=>selectArea(b.dataset.area)));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeDialog(b.dataset.close)));
$("profileButton").addEventListener("click",()=>openDialog("profileDialog"));
$("crownTrigger").addEventListener("click",handleCrown);
$("claimOwnership").addEventListener("click",claimOwnership);
$("ownerOrb").addEventListener("click",openOwner);
$("ownerProfileShortcut").addEventListener("click",()=>{closeDialog("ownerDialog");openDialog("profileDialog");});
$("googleSignIn").addEventListener("click",()=>googleSignIn(false));
$("googleSignOut").addEventListener("click",signOutGoogle);
$("connectGmail").addEventListener("click",connectGmail);
$("openInbox").addEventListener("click",()=>{closeDialog("profileDialog");loadInbox();});
$("composeEmail").addEventListener("click",()=>{closeDialog("profileDialog");$("gmailInbox").hidden=true;$("gmailComposeForm").hidden=false;$("gmailTitle").textContent="Compose an email";$("gmailMessage").textContent=gmailToken?"Only Gmail send permission is used to send this message.":"Connect Gmail first from your profile.";openDialog("gmailDialog");});
$("gmailComposeForm").addEventListener("submit",sendGmail);
$("ownerEntryForm").addEventListener("submit",publishEntry);
$("editSelectedArea").addEventListener("click",()=>{const item=memory.areas.find(a=>a.areaKey===currentAreaKey);editEntry(item||{id:"",title:areaInfo[currentAreaKey].name,body:areaInfo[currentAreaKey].description,areaKey:currentAreaKey},"areas");});
document.querySelectorAll(".mini-tab").forEach(b=>b.addEventListener("click",()=>activateEditorTab(b.dataset.editor)));
$("statusDismiss").addEventListener("click",()=>$("statusStrip").hidden=true);
$("trollButton").addEventListener("click",()=>{
  const card=document.querySelector(".troll-game");card.classList.add("trolled");
  $("trollResult").textContent="😂 HA! تۆ ترۆڵ کرایت! — U GOT TROLLED!";
  setTimeout(()=>card.classList.remove("trolled"),1300);
});
const wheelPrizes=["Try again!","A mystery prize!","Congratulations!","Almost… spin again!","A surprise awaits!","You win… absolutely nothing!","Nice spin!"];
let wheelBusy=false;
$("spinButton").addEventListener("click",()=>{
  if(wheelBusy)return;wheelBusy=true;
  const wheel=$("wheel");wheel.classList.remove("spinning");void wheel.offsetWidth;wheel.classList.add("spinning");$("wheelResult").textContent="The wheel is choosing…";
  setTimeout(()=>{wheel.classList.remove("spinning");$("wheelResult").textContent=`🎡 ${wheelPrizes[Math.floor(Math.random()*wheelPrizes.length)]}`;wheelBusy=false;},3050);
});

setupFirebase();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("/service-worker.js").catch(e=>console.warn("Service worker",e));
